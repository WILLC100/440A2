5B

The output file orders are in as follows :

Initial non-blocked random point
100 generated randomized actions
100 points moving in accordance with transition state 90/10 rule and staying in bounds of the grid
100 readings using the 90/5/5 rule to determine the estimated type of cell


The grids were generated using gridmaker.py, and each grid is stored in it's own folder from under grids
Each random action was generated using ManagerB main system. It may take multiple runs/stops of ManagerB in order to produce an output file
as the current version may not write to the file correctly.